package com.example.batch.spring.batch.listener;

import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.batch.core.annotation.OnSkipInRead;
import org.springframework.batch.item.file.FlatFileParseException;

public class Productlistener {
	
	@OnSkipInRead
	public void onSkipRead(Throwable t)
	{
		if(t instanceof FlatFileParseException)
		{
			FlatFileParseException ffep=(FlatFileParseException)t;
			onskip(ffep.getInput(),"filr/skip.txt");
			
		}
	}

	private void onskip(Object input, String fname) {
		// TODO Auto-generated method stub
		FileOutputStream fos=null;
		try
		{
			fos=new FileOutputStream(fname,true);
			fos.write(input.toString().getBytes());
			fos.write("\r\n".getBytes());
			fos.close();
		}
		catch(IOException e)
		{
			
		}
		
	}

}
