package com.example.batch.spring.batch.model;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Product {
	private int pid;
	private String pname;
	private String pdesc;
	private int price;

}
