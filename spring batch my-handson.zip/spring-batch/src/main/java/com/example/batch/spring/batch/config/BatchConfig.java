package com.example.batch.spring.batch.config;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.skip.AlwaysSkipItemSkipPolicy;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.oxm.xstream.XStreamMarshaller;

import com.example.batch.spring.batch.listener.Productlistener;
import com.example.batch.spring.batch.model.Product;

@Configuration
public class BatchConfig {

	@Autowired
	private JobBuilderFactory jbf;
	
	@Autowired
	private StepBuilderFactory sbf;
	
	/*Read from flat file*/
	@Bean
	public ItemReader<Product> reader()
	{
		FlatFileItemReader<Product> reader = new FlatFileItemReader<>();
		reader.setResource(new ClassPathResource("products.csv"));
		DefaultLineMapper<Product> lineMapper = new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setNames("pid","pname","pdesc","price");
		lineTokenizer.setDelimiter("|");
		BeanWrapperFieldSetMapper<Product> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(Product.class);
		lineMapper.setLineTokenizer(lineTokenizer);
		lineMapper.setFieldSetMapper(fieldSetMapper);
		reader.setLineMapper(lineMapper);
		return reader;
	}
	
	/*Read from  xml*/

	@Bean
	public StaxEventItemReader xmlItemReader()
	{
		 StaxEventItemReader reader = new StaxEventItemReader<>();
		 reader.setResource(new ClassPathResource("products.xml"));
		 reader.setFragmentRootElementName("product");
		 Jaxb2Marshaller marshaller=new Jaxb2Marshaller();
		 marshaller.setClassesToBeBound(Product.class);
		 reader.setUnmarshaller(marshaller);
		 return reader;
	}
	/*Read from json

	@Bean
	public JsonItemReader<Product> jsonItemReader()
	{
		 JsonItemReader<Product> jsonItemReader = new JsonItemReader<>(new ClassPathResource("products.json"),new JacksonJsonObjectReader(Product.class ));
		 return jsonItemReader;
	}
	*/
	/*Read from database*/
	@Bean
	public JdbcCursorItemReader<Product> jdbcCursorItemReader()
	{
		System.out.println("reading here");
		JdbcCursorItemReader<Product> reader = new JdbcCursorItemReader<>();
		reader.setDataSource(dataSource());
		reader.setSql("select pid,pname,pdesc,price from products");
		BeanPropertyRowMapper<Product> mapper = new BeanPropertyRowMapper<>();
		mapper.setMappedClass(Product.class);
		reader.setRowMapper(mapper);
		return reader;
	}
	/***********************************END OF READERS **********************************/
	/*writing to a flatfile*/
	@Bean
	public FlatFileItemWriter<Product> flatFileItemWriter()
	{
		System.out.println("writing here");
		FlatFileItemWriter<Product> writer = new FlatFileItemWriter<>();
		writer.setResource(new FileSystemResource("output.csv"));
		writer.setShouldDeleteIfExists(true);
		writer.setAppendAllowed(true);
		writer.setForceSync(true);
		DelimitedLineAggregator<Product> lineAggregator = new DelimitedLineAggregator<>();
		lineAggregator.setDelimiter(",");
		BeanWrapperFieldExtractor<Product> fieldExtractor = new BeanWrapperFieldExtractor<>();
		fieldExtractor.setNames(new String[] {"pid","pname","pdesc","price"});
		lineAggregator.setFieldExtractor(fieldExtractor);
		writer.setLineAggregator(lineAggregator);
		writer.close();
		return writer;
		
		
	}
	/*writing to xml
	@Bean
	public StaxEventItemWriter xmlWriter()
	{
		StaxEventItemWriter writer = new StaxEventItemWriter();
		XStreamMarshaller marshaller=new XStreamMarshaller();
		writer.setResource(new ClassPathResource("output.xml"));
		writer.setMarshaller(marshaller);
		writer.setRootTagName("products");
		return writer;
	}
	*/
	

	
	/*writing to database*/
	@Bean
	public ItemWriter<Product> writer()
	{
		 JdbcBatchItemWriter<Product> writer = new JdbcBatchItemWriter<>();
		 writer.setDataSource(dataSource());
		 writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Product>());
		 writer.setSql("insert into products(PID,PNAME,PDESC,PRICE) values(:pid,:pname,:pdesc,:price)");
		return writer;
	}
	
	
	
	
	@Bean
	public DataSource dataSource()
	{
	   DriverManagerDataSource dataSource = new DriverManagerDataSource();
	   dataSource.setUrl("jdbc:mysql://localhost:3306/mydb");
	   dataSource.setUsername("root");
	   dataSource.setPassword("jahnavi@99");
	   return dataSource;
	}
	@Bean
	public Step step()
	{
		return sbf.get("step1")
				.<Product,Product>chunk(2)
				.reader( reader())
				.writer(flatFileItemWriter())
				.faultTolerant()
				.skip(FlatFileParseException.class)
				.skipPolicy(new AlwaysSkipItemSkipPolicy())
				.listener(new Productlistener())
				.build();
	}
	@Bean
	public Job job()
	{
		return jbf.get("job1")
				.incrementer(new RunIdIncrementer())
				.start(step())
				.build();
		
	}
}
